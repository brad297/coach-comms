# Coach Comms — Five Star Solutions
## Deploy in 5 minutes on Render (free)

### Step 1 — Upload to GitHub
1. Go to github.com and create a free account if you don't have one
2. Click "New repository" — name it "coach-comms"
3. Upload all these files to the repository

### Step 2 — Deploy on Render
1. Go to render.com and sign up free
2. Click "New" → "Web Service"
3. Connect your GitHub account and select the coach-comms repo
4. Render will auto-detect the settings from render.yaml
5. Click "Create Web Service"

### Step 3 — Add your API key
1. In Render dashboard, go to your service → Environment
2. Add environment variable:
   - Key: ANTHROPIC_API_KEY
   - Value: your Anthropic API key (get from console.anthropic.com)
3. Click Save — Render will redeploy automatically

### Step 4 — Share with clients
Render gives you a URL like: https://coach-comms.onrender.com
That URL works on any device — phone, tablet, desktop.

### Your API key stays private
The key never appears in the frontend code. All AI calls go through
your server, so clients can use the tool without ever seeing your key.

### Cost
- Render free tier: $0/month (spins down after 15 min of inactivity)
- Render paid tier: $7/month (always on — recommended for client use)
- Anthropic API: roughly $0.01-0.03 per draft depending on length
